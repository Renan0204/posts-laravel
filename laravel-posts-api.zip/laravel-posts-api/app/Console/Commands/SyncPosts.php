<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Models\Post;
use Illuminate\Support\Facades\Http;

class SyncPosts extends Command
{
    protected $signature = 'sync:posts';
    protected $description = 'Sincroniza os posts da API externa';

    public function handle()
    {
        $this->info('Sincronizando posts...');

        try {
            $response = Http::get('https://jsonplaceholder.typicode.com/posts');

            if ($response->successful()) {
                $posts = $response->json();

                foreach ($posts as $post) {
                    Post::updateOrCreate(
                        ['id' => $post['id']],
                        [
                            'user_id' => $post['userId'],
                            'title' => $post['title'],
                            'body' => $post['body'],
                        ]
                    );
                }

                $this->info('Posts sincronizados com sucesso!');
            } else {
                $this->error('Erro ao acessar a API. Status: ' . $response->status());
            }
        } catch (\Exception $e) {
            $this->error('Erro ao conectar com a API externa: ' . $e->getMessage());
        }
    }
}
